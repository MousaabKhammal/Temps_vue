var vm = new Vue({
    el: '#eltemps',
    data: {
        ciutatActual: null,
		ciutats: [
				"Barcelona",
				"Lleida",
				"Zaragoza",
				"Sevilla",
				"Madrid",
				"Paris",
				"Melbourne",
				"Moscow",
				"Pekin",
				"Marrakech"]
    },
    created: function () {
        this.getWeather(this.ciutats[0]);
    },
    methods: {
        getWeather(city) {
            var url ='https://api.openweathermap.org/data/2.5/weather?q=' + city + '&units=metric&lang=ca&appid=644da4f2a1231c6611d2e2d8abb1fc90'
            fetch(url)
                .then(function (response) {
                    return response.json()
                })
                .then(function (item) {
                    vm.ciutatActual = item;
                })
                .catch(function(error) {
                    console.log(error);
                })
        }
    }
})


